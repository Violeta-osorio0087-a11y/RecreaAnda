
  # Aplicación de Comunidad Interactiva

  This is a code bundle for Aplicación de Comunidad Interactiva. The original project is available at https://www.figma.com/design/0w4PXOZtd28U1bp9ctDQ9h/Aplicaci%C3%B3n-de-Comunidad-Interactiva.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  