import { useState } from 'react';
import { Phone, Mail, Calendar as CalendarIcon, Video, Clock, Check, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';

interface Profesional {
  id: number;
  name: string;
  specialty: string;
  description: string;
  experience: string;
  availability: string;
  initials: string;
  color: string;
}

interface Appointment {
  id: string;
  professionalId: number;
  professionalName: string;
  specialty: string;
  date: Date;
  time: string;
  color: string;
}

export function AsesoriaProfesional() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [view, setView] = useState<'professionals' | 'calendar'>('professionals');
  const [selectedProfessional, setSelectedProfessional] = useState<Profesional | null>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  const profesionales: Profesional[] = [
    {
      id: 1,
      name: 'Dr. José Ramírez',
      specialty: 'Psicología Geriátrica',
      description: 'Especialista en salud mental y bienestar emocional para adultos mayores',
      experience: '15 años de experiencia',
      availability: 'Lunes a Viernes',
      initials: 'JR',
      color: 'bg-blue-500',
    },
    {
      id: 2,
      name: 'Dra. Patricia Morales',
      specialty: 'Nutrición',
      description: 'Planes alimenticios personalizados para una vida saludable',
      experience: '12 años de experiencia',
      availability: 'Martes y Jueves',
      initials: 'PM',
      color: 'bg-green-500',
    },
    {
      id: 3,
      name: 'Lic. Fernando Castro',
      specialty: 'Fisioterapia',
      description: 'Rehabilitación y terapia física para mejorar movilidad',
      experience: '10 años de experiencia',
      availability: 'Lunes a Sábado',
      initials: 'FC',
      color: 'bg-purple-500',
    },
    {
      id: 4,
      name: 'Dra. Sofía Jiménez',
      specialty: 'Medicina General',
      description: 'Atención médica integral y seguimiento de salud',
      experience: '20 años de experiencia',
      availability: 'Lunes, Miércoles y Viernes',
      initials: 'SJ',
      color: 'bg-red-500',
    },
    {
      id: 5,
      name: 'Lic. Roberto Vega',
      specialty: 'Trabajo Social',
      description: 'Apoyo en trámites, servicios y orientación social',
      experience: '8 años de experiencia',
      availability: 'Lunes a Viernes',
      initials: 'RV',
      color: 'bg-orange-500',
    },
    {
      id: 6,
      name: 'Dra. Andrea López',
      specialty: 'Neurología',
      description: 'Evaluación y tratamiento de condiciones neurológicas',
      experience: '18 años de experiencia',
      availability: 'Martes y Jueves',
      initials: 'AL',
      color: 'bg-indigo-500',
    },
  ];

  const availableTimes = [
    '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
  ];

  const handleBookAppointment = (professional: Profesional) => {
    setSelectedProfessional(professional);
    setShowBookingModal(true);
    setSelectedDate(null);
    setSelectedTime('');
  };

  const confirmAppointment = () => {
    if (selectedProfessional && selectedDate && selectedTime) {
      const newAppointment: Appointment = {
        id: Date.now().toString(),
        professionalId: selectedProfessional.id,
        professionalName: selectedProfessional.name,
        specialty: selectedProfessional.specialty,
        date: selectedDate,
        time: selectedTime,
        color: selectedProfessional.color,
      };
      setAppointments([...appointments, newAppointment]);
      setShowBookingModal(false);
      setSelectedProfessional(null);
      setSelectedDate(null);
      setSelectedTime('');
    }
  };

  const cancelAppointment = (appointmentId: string) => {
    setAppointments(appointments.filter(apt => apt.id !== appointmentId));
  };

  // Funciones del calendario
  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay();
  };

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

  const getAppointmentsForDay = (day: number, month: number, year: number) => {
    return appointments.filter(apt => {
      const aptDate = new Date(apt.date);
      return (
        aptDate.getDate() === day &&
        aptDate.getMonth() === month &&
        aptDate.getFullYear() === year
      );
    });
  };

  const previousMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentMonth, currentYear);
    const firstDay = getFirstDayOfMonth(currentMonth, currentYear);
    const days = [];

    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="p-2 min-h-24"></div>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const appointmentsForDay = getAppointmentsForDay(day, currentMonth, currentYear);
      const isToday = 
        day === new Date().getDate() &&
        currentMonth === new Date().getMonth() &&
        currentYear === new Date().getFullYear();

      days.push(
        <div
          key={day}
          className={`p-2 border border-gray-200 min-h-24 rounded-lg ${
            isToday ? 'bg-blue-50 border-blue-300' : 'bg-white'
          }`}
        >
          <div className={`mb-1 ${isToday ? 'text-blue-600' : 'text-gray-700'}`}>
            {day}
          </div>
          <div className="space-y-1">
            {appointmentsForDay.map((apt) => (
              <div
                key={apt.id}
                className={`text-xs ${apt.color} text-white px-2 py-1 rounded`}
                title={`${apt.professionalName} - ${apt.specialty} - ${apt.time}`}
              >
                <div className="truncate">{apt.time}</div>
                <div className="truncate">{apt.specialty}</div>
              </div>
            ))}
          </div>
        </div>
      );
    }

    return days;
  };

  const getNextDays = (count: number) => {
    const days = [];
    const today = new Date();
    for (let i = 1; i <= count; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      days.push(date);
    }
    return days;
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-blue-900 mb-2">Asesoría Profesional</h1>
          <p className="text-gray-600">Conecta con profesionales especializados en tu bienestar</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setView('professionals')}
            variant={view === 'professionals' ? 'default' : 'outline'}
            className={view === 'professionals' ? 'bg-blue-500 hover:bg-blue-600' : ''}
          >
            Profesionales
          </Button>
          <Button
            onClick={() => setView('calendar')}
            variant={view === 'calendar' ? 'default' : 'outline'}
            className={view === 'calendar' ? 'bg-blue-500 hover:bg-blue-600' : ''}
          >
            <CalendarIcon className="w-4 h-4 mr-2" />
            Mis Citas
          </Button>
        </div>
      </div>

      {view === 'professionals' ? (
        <>
          {appointments.length > 0 && (
            <Card className="mb-6 bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-gray-900 flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-500" />
                  Citas Agendadas ({appointments.length})
                </CardTitle>
                <CardDescription>
                  Tienes {appointments.length} {appointments.length === 1 ? 'cita agendada' : 'citas agendadas'}
                </CardDescription>
              </CardHeader>
            </Card>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {profesionales.map((prof) => (
              <Card key={prof.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <Avatar className="w-16 h-16">
                      <AvatarFallback className={`${prof.color} text-white`}>
                        {prof.initials}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <CardTitle className="text-gray-900">{prof.name}</CardTitle>
                      <Badge className="mt-1 bg-blue-100 text-blue-700 border-0">
                        {prof.specialty}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <CardDescription>{prof.description}</CardDescription>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-gray-700">
                      <Clock className="w-4 h-4 text-blue-500" />
                      <span>{prof.experience}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <CalendarIcon className="w-4 h-4 text-green-500" />
                      <span>{prof.availability}</span>
                    </div>
                  </div>

                  <div className="pt-4 flex gap-2">
                    <Button 
                      className="flex-1 bg-blue-500 hover:bg-blue-600"
                      onClick={() => handleBookAppointment(prof)}
                    >
                      <CalendarIcon className="w-4 h-4 mr-2" />
                      Agendar Cita
                    </Button>
                    <Button variant="outline" className="flex-1">
                      <Video className="w-4 h-4 mr-2" />
                      Video Llamada
                    </Button>
                  </div>

                  <div className="pt-2 flex gap-4 text-gray-600 border-t border-gray-200">
                    <a href="#" className="flex items-center gap-2 hover:text-blue-500 transition-colors mt-2">
                      <Phone className="w-4 h-4" />
                      <span>Llamar</span>
                    </a>
                    <a href="#" className="flex items-center gap-2 hover:text-blue-500 transition-colors mt-2">
                      <Mail className="w-4 h-4" />
                      <span>Enviar Email</span>
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      ) : (
        <div className="space-y-6">
          {/* Lista de citas próximas */}
          {appointments.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-gray-900">Próximas Citas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {appointments
                    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                    .map(apt => (
                      <div key={apt.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-full ${apt.color} flex items-center justify-center text-white`}>
                            <CalendarIcon className="w-6 h-6" />
                          </div>
                          <div>
                            <h3 className="text-gray-900">{apt.professionalName}</h3>
                            <p className="text-gray-600">{apt.specialty}</p>
                            <p className="text-gray-500 flex items-center gap-2 mt-1">
                              <CalendarIcon className="w-4 h-4" />
                              {new Date(apt.date).toLocaleDateString('es-ES', { 
                                weekday: 'long', 
                                year: 'numeric', 
                                month: 'long', 
                                day: 'numeric' 
                              })}
                              <Clock className="w-4 h-4 ml-2" />
                              {apt.time}
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          className="text-red-500 border-red-500 hover:bg-red-50"
                          onClick={() => cancelAppointment(apt.id)}
                        >
                          <X className="w-4 h-4 mr-2" />
                          Cancelar
                        </Button>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Calendario */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-gray-900">Calendario de Citas</CardTitle>
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="sm" onClick={previousMonth}>
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="text-gray-700 min-w-[150px] text-center">
                    {monthNames[currentMonth]} {currentYear}
                  </span>
                  <Button variant="outline" size="sm" onClick={nextMonth}>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              {appointments.length === 0 && (
                <CardDescription className="text-center py-4">
                  No tienes citas agendadas. Ve a "Profesionales" para agendar una cita.
                </CardDescription>
              )}
            </CardHeader>
            {appointments.length > 0 && (
              <CardContent>
                <div className="grid grid-cols-7 gap-2 mb-2">
                  {dayNames.map(day => (
                    <div key={day} className="text-center text-gray-600 py-2">
                      {day}
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-2">
                  {renderCalendar()}
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      )}

      {/* Modal de agendamiento */}
      {showBookingModal && selectedProfessional && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-gray-900">Agendar Cita</CardTitle>
                  <CardDescription>
                    {selectedProfessional.name} - {selectedProfessional.specialty}
                  </CardDescription>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowBookingModal(false)}
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Selección de fecha */}
              <div>
                <h3 className="text-gray-700 mb-3">Selecciona una fecha:</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {getNextDays(8).map((date, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedDate(date)}
                      className={`p-3 border rounded-lg transition-all ${
                        selectedDate?.toDateString() === date.toDateString()
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-300 hover:border-blue-300'
                      }`}
                    >
                      <div className="text-gray-600 text-xs">
                        {date.toLocaleDateString('es-ES', { weekday: 'short' })}
                      </div>
                      <div className="text-gray-900">
                        {date.getDate()}
                      </div>
                      <div className="text-gray-600 text-xs">
                        {date.toLocaleDateString('es-ES', { month: 'short' })}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Selección de hora */}
              {selectedDate && (
                <div>
                  <h3 className="text-gray-700 mb-3">Selecciona un horario:</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {availableTimes.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`p-3 border rounded-lg transition-all ${
                          selectedTime === time
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-300 hover:border-blue-300'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Botones de acción */}
              <div className="flex gap-3 pt-4 border-t">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setShowBookingModal(false)}
                >
                  Cancelar
                </Button>
                <Button
                  className="flex-1 bg-blue-500 hover:bg-blue-600"
                  onClick={confirmAppointment}
                  disabled={!selectedDate || !selectedTime}
                >
                  <Check className="w-4 h-4 mr-2" />
                  Confirmar Cita
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
