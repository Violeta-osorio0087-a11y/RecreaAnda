export function CarmenAvatar({ className = "w-full h-full" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 200"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Background circle */}
      <circle cx="100" cy="100" r="95" fill="#fdf2f8" />
      
      {/* Body/Neck */}
      <ellipse cx="100" cy="160" rx="45" ry="35" fill="#ec4899" />
      <rect x="85" y="140" width="30" height="30" fill="#fbbf24" rx="5" />
      
      {/* Head */}
      <circle cx="100" cy="90" r="45" fill="#fde68a" />
      
      {/* Hair */}
      <path
        d="M 55 80 Q 50 60, 60 50 Q 70 45, 80 48 Q 90 40, 100 38 Q 110 40, 120 48 Q 130 45, 140 50 Q 150 60, 145 80 Q 145 95, 140 100 L 60 100 Q 55 95, 55 80 Z"
        fill="#9ca3af"
      />
      
      {/* Hair detail - bun */}
      <circle cx="100" cy="55" r="18" fill="#9ca3af" />
      <circle cx="100" cy="55" r="15" fill="#6b7280" opacity="0.3" />
      
      {/* Ears */}
      <ellipse cx="58" cy="90" rx="8" ry="12" fill="#fcd34d" />
      <ellipse cx="142" cy="90" rx="8" ry="12" fill="#fcd34d" />
      
      {/* Earrings */}
      <circle cx="58" cy="98" r="4" fill="#ec4899" />
      <circle cx="142" cy="98" r="4" fill="#ec4899" />
      
      {/* Eyes */}
      <ellipse cx="85" cy="85" rx="8" ry="10" fill="white" />
      <ellipse cx="115" cy="85" rx="8" ry="10" fill="white" />
      <circle cx="85" cy="87" r="5" fill="#4b5563" />
      <circle cx="115" cy="87" r="5" fill="#4b5563" />
      <circle cx="87" cy="85" r="2" fill="white" />
      <circle cx="117" cy="85" r="2" fill="white" />
      
      {/* Eyebrows */}
      <path d="M 75 75 Q 85 72, 95 75" stroke="#6b7280" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <path d="M 105 75 Q 115 72, 125 75" stroke="#6b7280" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      
      {/* Glasses */}
      <ellipse cx="85" cy="85" rx="12" ry="13" fill="none" stroke="#a855f7" strokeWidth="2.5" />
      <ellipse cx="115" cy="85" rx="12" ry="13" fill="none" stroke="#a855f7" strokeWidth="2.5" />
      <line x1="97" y1="85" x2="103" y2="85" stroke="#a855f7" strokeWidth="2.5" />
      <path d="M 73 85 L 65 82" stroke="#a855f7" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M 127 85 L 135 82" stroke="#a855f7" strokeWidth="2.5" strokeLinecap="round" />
      
      {/* Nose */}
      <path d="M 100 90 L 98 100 L 102 100 Z" fill="#fbbf24" />
      
      {/* Smile */}
      <path
        d="M 80 105 Q 100 115, 120 105"
        stroke="#dc2626"
        strokeWidth="2.5"
        fill="none"
        strokeLinecap="round"
      />
      
      {/* Blush */}
      <ellipse cx="70" cy="100" rx="10" ry="6" fill="#fda4af" opacity="0.5" />
      <ellipse cx="130" cy="100" rx="10" ry="6" fill="#fda4af" opacity="0.5" />
      
      {/* Collar detail */}
      <circle cx="100" cy="145" r="3" fill="white" />
      <circle cx="100" cy="155" r="3" fill="white" />
      
      {/* Decorative necklace */}
      <ellipse cx="100" cy="140" rx="20" ry="3" fill="#fbbf24" opacity="0.6" />
      <circle cx="100" cy="143" r="4" fill="#ec4899" />
    </svg>
  );
}
