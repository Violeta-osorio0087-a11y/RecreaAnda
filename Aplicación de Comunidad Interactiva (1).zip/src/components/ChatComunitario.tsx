import { useState } from 'react';
import { Send, User } from 'lucide-react';
import { Card } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Button } from './ui/button';

interface Message {
  id: number;
  user: string;
  message: string;
  time: string;
  color: string;
}

export function ChatComunitario() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      user: 'María González',
      message: '¡Hola a todos! ¿Cómo están hoy?',
      time: '10:30 AM',
      color: 'bg-blue-500',
    },
    {
      id: 2,
      user: 'Carlos Ruiz',
      message: 'Muy bien, gracias. ¿Alguien va a la clase de yoga esta tarde?',
      time: '10:32 AM',
      color: 'bg-green-500',
    },
    {
      id: 3,
      user: 'Ana Torres',
      message: 'Sí, yo voy. Nos vemos a las 4pm',
      time: '10:35 AM',
      color: 'bg-purple-500',
    },
    {
      id: 4,
      user: 'Pedro Martínez',
      message: '¿Hay espacio para uno más?',
      time: '10:37 AM',
      color: 'bg-orange-500',
    },
  ]);
  const [newMessage, setNewMessage] = useState('');

  const handleSend = () => {
    if (newMessage.trim()) {
      const now = new Date();
      setMessages([
        ...messages,
        {
          id: messages.length + 1,
          user: 'Tú',
          message: newMessage,
          time: now.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
          color: 'bg-blue-600',
        },
      ]);
      setNewMessage('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-blue-900 mb-2">Chat Comunitario</h1>
        <p className="text-gray-600">Conecta con otros miembros de la comunidad Recrea Andar</p>
      </div>

      <Card className="h-[600px] flex flex-col">
        {/* Messages area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className="flex gap-3">
              <Avatar className="w-10 h-10 flex-shrink-0">
                <AvatarFallback className={msg.color}>
                  <User className="w-5 h-5 text-white" />
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-gray-900">{msg.user}</span>
                  <span className="text-gray-400">{msg.time}</span>
                </div>
                <p className="text-gray-700 mt-1">{msg.message}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Input area */}
        <div className="border-t border-gray-200 p-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Escribe tu mensaje..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Button onClick={handleSend} className="bg-blue-500 hover:bg-blue-600">
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
