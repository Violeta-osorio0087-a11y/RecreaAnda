import { useState } from 'react';
import { Send, User, Sparkles, MessageCircle, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { CarmenAvatar } from './CarmenAvatar';
import { ChuyAvatar } from './ChuyAvatar';

interface ChatMessage {
  id: number;
  sender: 'user' | 'bot';
  message: string;
  time: string;
  suggestedSection?: 'chat' | 'clases' | 'asesoria' | 'juegos';
  buttonText?: string;
}

interface ChatbotIAProps {
  onNavigate?: (section: 'chat' | 'clases' | 'asesoria' | 'juegos' | 'chatbot') => void;
}

type Guide = 'carmen' | 'chuy';

export function ChatbotIA({ onNavigate }: ChatbotIAProps) {
  const [selectedGuide, setSelectedGuide] = useState<Guide | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [userMood, setUserMood] = useState<'neutral' | 'happy' | 'sad' | 'anxious' | 'frustrated' | 'lonely'>('neutral');
  const [messageCount, setMessageCount] = useState(0);

  const quickQuestions = [
    '¿Qué puedo hacer aquí?',
    'Quiero hacer ejercicio',
    'Necesito hablar con un profesional',
    'Juegos para la memoria',
    'Conocer otras personas',
  ];

  // Detectar el estado de ánimo del usuario
  const detectMood = (message: string): 'neutral' | 'happy' | 'sad' | 'anxious' | 'frustrated' | 'lonely' => {
    const msg = message.toLowerCase();
    
    // Detectar tristeza o depresión
    if (msg.includes('triste') || msg.includes('deprim') || msg.includes('mal') || msg.includes('llorar') || 
        msg.includes('dolor') || msg.includes('vacío') || msg.includes('solo') && msg.includes('siento') ||
        msg.includes('no puedo') || msg.includes('cansad') || msg.includes('aburrido')) {
      return 'sad';
    }
    
    // Detectar ansiedad o preocupación
    if (msg.includes('preocup') || msg.includes('ansio') || msg.includes('nervio') || msg.includes('mied') ||
        msg.includes('estrés') || msg.includes('intranquil') || msg.includes('agobiad')) {
      return 'anxious';
    }
    
    // Detectar frustración o enojo
    if (msg.includes('frustrad') || msg.includes('enojad') || msg.includes('molest') || msg.includes('enfadad') ||
        msg.includes('rabia') || msg.includes('no entiendo') || msg.includes('no funciona')) {
      return 'frustrated';
    }
    
    // Detectar soledad
    if (msg.includes('solo') || msg.includes('sola') || msg.includes('aislad') || msg.includes('nadie') ||
        msg.includes('compañía') || msg.includes('aburrimiento')) {
      return 'lonely';
    }
    
    // Detectar felicidad
    if (msg.includes('bien') || msg.includes('feliz') || msg.includes('contento') || msg.includes('alegre') ||
        msg.includes('genial') || msg.includes('excelente') || msg.includes('maravillos')) {
      return 'happy';
    }
    
    return 'neutral';
  };

  const getBotResponse = (userMessage: string): { message: string; suggestedSection?: 'chat' | 'clases' | 'asesoria' | 'juegos'; buttonText?: string } => {
    const msg = userMessage.toLowerCase();
    const detectedMood = detectMood(userMessage);
    
    const isChuy = selectedGuide === 'chuy';
    
    // Respuestas empáticas según el estado de ánimo detectado
    if (detectedMood === 'sad') {
      return {
        message: isChuy 
          ? 'Amigo, veo que hoy no es tu mejor día. Pero aquí me tienes para lo que necesites. A veces platicar con alguien nos ayuda a ver las cosas de otra manera. Tenemos psicólogos muy buenos que te pueden echar la mano, o si prefieres, hay buena gente en la comunidad con quien charlar. ¿Qué te late más?'
          : 'Ay cariño, noto que no te sientes muy bien hoy. Quiero que sepas que estoy aquí para ti y no estás solo. A veces hablar con alguien puede ayudar mucho. Tenemos psicólogos maravillosos que pueden escucharte, o si prefieres, puedes charlar con otras personas en nuestra comunidad. ¿Qué te parece mejor?',
        suggestedSection: 'asesoria',
        buttonText: 'Hablar con un Profesional'
      };
    }
    
    if (detectedMood === 'anxious') {
      return {
        message: isChuy
          ? 'Compa, te noto un poco inquieto. Tranquilo, todo va a salir bien. ¿Qué tal si intentas algo que te relaje? El Yoga o el Tai Chi son muy buenos para bajar las revoluciones, o si gustas, el psicólogo está para ayudarte. ¿Qué prefieres?'
          : 'Querido, percibo que estás un poco preocupado. Respira hondo conmigo, todo va a estar bien. Te recomiendo actividades que pueden ayudarte a relajarte como Yoga o Tai Chi, o si prefieres, nuestro psicólogo está disponible para ayudarte. ¿Qué te gustaría intentar?',
        suggestedSection: 'clases',
        buttonText: 'Ver Clases Relajantes'
      };
    }
    
    if (detectedMood === 'frustrated') {
      return {
        message: isChuy
          ? 'Te entiendo perfectamente, amigo. A veces las cosas no salen como uno quiere y es normal sentirse así. ¿Qué te parece si hacemos algo diferente? Podemos echar unos juegos para distraernos, o si quieres desahogarte, aquí estoy para escucharte.'
          : 'Entiendo tu frustración, cariño. A veces las cosas no salen como queremos y está bien sentirse así. ¿Qué te parece si hacemos algo diferente? Podemos probar algún juego para distraerte, o si quieres hablar sobre lo que te molesta, estoy aquí para escucharte.',
        suggestedSection: 'juegos',
        buttonText: 'Distraerte con Juegos'
      };
    }
    
    if (detectedMood === 'lonely') {
      return {
        message: isChuy
          ? '💙 Hermano, te entiendo. Pero déjame decirte que aquí en Recrea Andar hay un montón de buena gente esperando conocerte. La comunidad es muy padre y te van a recibir con los brazos abiertos. ¿Te animas a conocerlos en el chat?'
          : '💗 Ay querido, me da mucha pena que te sientas solo. Pero sabes qué, aquí en Recrea Andar hay una comunidad preciosa de personas que están deseando conocerte y compartir contigo. ¿Qué te parece si te llevo al chat comunitario? Estoy segura de que harás amigos maravillosos.',
        suggestedSection: 'chat',
        buttonText: 'Conocer Nuevos Amigos'
      };
    }
    
    if (detectedMood === 'happy') {
      return {
        message: isChuy
          ? '¡Eso es, compa! Me da gusto verte con esa actitud tan positiva. Con ese ánimo todo se puede. ¿Qué te gustaría hacer hoy? Hay muchas actividades padres esperándote.'
          : '¡Qué alegría me da verte tan bien, cariño! Tu energía positiva es contagiosa. Con ese ánimo tan lindo, ¿qué te gustaría hacer hoy? Tenemos muchas actividades divertidas esperándote.',
      };
    }

    // Respuestas sobre cómo se siente
    if (msg.includes('cómo') && (msg.includes('siento') || msg.includes('estoy') || msg.includes('me siento'))) {
      return {
        message: isChuy
          ? 'Gracias por la confianza, amigo. Me importa mucho cómo te sientes. Recuerda que aquí estamos para echarnos la mano. ¿Hay algo en particular que quieras hacer hoy?'
          : 'Gracias por compartir eso conmigo, querido. Me importa mucho cómo te sientes. Recuerda que no estás solo y estoy aquí para apoyarte en lo que necesites. ¿Hay algo específico que te gustaría hacer hoy?'
      };
    }

    // Respuestas sobre explorar o qué hacer
    if (msg.includes('qué') && (msg.includes('hacer') || msg.includes('puedo'))) {
      return {
        message: isChuy
          ? '¡Buena pregunta! Recrea Andar tiene muchas cosas interesantes:\\n\\n🗨️ Chat Comunitario - Para conocer gente\\n🎨 Clases Recreativas - Actividades muy padres\\n👨‍⚕️ Asesoría Profesional - Apoyo de especialistas\\n🧠 Juegos Cognitivos - Para ejercitar la mente\\n\\n¿Por cuál empezamos?'
          : '¡Qué bueno que preguntas! Recrea Andar tiene muchas cosas maravillosas:\\n\\n🗨️ Chat Comunitario - Para conocer amigos\\n🎨 Clases Recreativas - Actividades divertidas\\n👨‍⚕️ Asesoría Profesional - Apoyo de especialistas\\n🧠 Juegos Cognitivos - Ejercita tu mente\\n\\n¿Cuál te gustaría explorar primero?'
      };
    }

    // Respuestas sobre clases y ejercicio
    if (msg.includes('clase') || msg.includes('actividad') || msg.includes('ejercicio') || msg.includes('bailar') || msg.includes('yoga')) {
      return {
        message: isChuy
          ? '¡Órale, qué bueno! Tenemos clases muy buenas: Yoga, Baile, Tai Chi, Pintura, Club de Lectura y Cocina Saludable. Todas están de lujo para mantenerte activo. ¿Te las muestro?'
          : '¡Excelente elección! Tenemos clases maravillosas como Yoga, Baile, Tai Chi, Pintura, Club de Lectura y Cocina Saludable. Todas son muy divertidas y perfectas para mantenerte activo. ¿Te gustaría que te lleve a ver todas las opciones?',
        suggestedSection: 'clases',
        buttonText: 'Ver Clases Recreativas'
      };
    }
    
    // Respuestas sobre inscripciones
    if (msg.includes('inscrib') || msg.includes('registro') || msg.includes('unir')) {
      return {
        message: isChuy
          ? 'Es muy sencillo, amigo. Nomás tienes que ir a Clases Recreativas y darle clic a "Inscribirse" en la que te guste. ¿Te llevo para allá?'
          : 'Es muy fácil, querido. Solo tienes que ir a la sección de Clases Recreativas y hacer clic en \"Inscribirse\" en la actividad que te guste. ¿Quieres que te lleve allá ahora?',
        suggestedSection: 'clases',
        buttonText: 'Ir a Clases'
      };
    }
    
    // Respuestas sobre profesionales y salud
    if (msg.includes('profesional') || msg.includes('doctor') || msg.includes('médico') || msg.includes('salud') || msg.includes('psicólog') || msg.includes('nutrición')) {
      return {
        message: isChuy
          ? 'Contamos con profesionales de primera: Psicología, Nutrición, Fisioterapia, Medicina General, Trabajo Social y Neurología. Todos muy preparados y listos para ayudarte. ¿Quieres ver sus horarios y agendar una cita?'
          : 'Contamos con profesionales muy capacitados en Psicología, Nutrición, Fisioterapia, Medicina General, Trabajo Social y Neurología. Todos están aquí para cuidarte. ¿Te gustaría ver sus horarios y agendar una cita?',
        suggestedSection: 'asesoria',
        buttonText: 'Ver Profesionales'
      };
    }
    
    // Respuestas sobre horarios
    if (msg.includes('horario') || msg.includes('hora') || msg.includes('cuándo')) {
      return {
        message: isChuy
          ? 'Abrimos de Lunes a Viernes de 8:00 AM a 6:00 PM, y los Sábados de 9:00 AM a 2:00 PM. Cada clase y cita tiene su horario específico que puedes checar en cada sección. ¿Quieres que te muestre alguna?'
          : 'Estamos abiertos de Lunes a Viernes de 8:00 AM a 6:00 PM, y los Sábados de 9:00 AM a 2:00 PM. Las clases y citas tienen horarios específicos que puedes ver en cada sección. ¿Quieres que te muestre alguna en particular?'
      };
    }
    
    // Respuestas sobre juegos cognitivos
    if (msg.includes('juego') || msg.includes('cognitivo') || msg.includes('memoria') || msg.includes('mente') || msg.includes('cerebro')) {
      return {
        message: isChuy
          ? '¡Qué bien que quieras ejercitar la mente! Tenemos juegos muy entretenidos: Memoria de Pares, Sopa de Letras, Sudoku, Crucigramas y más. Perfectos para mantener el cerebro activo. ¿Vamos a jugar?'
          : '¡Qué bien que quieras ejercitar tu mente! Tenemos juegos muy entretenidos como Memoria de Pares, Sudoku, Crucigramas, Rompecabezas y más. Son perfectos para mantener tu cerebro activo. ¿Vamos a jugar?',
        suggestedSection: 'juegos',
        buttonText: 'Ir a Juegos'
      };
    }
    
    // Respuestas sobre chat comunitario
    if (msg.includes('chat') || msg.includes('gente') || msg.includes('amigo') || msg.includes('personas') || msg.includes('conocer') || msg.includes('comunidad')) {
      return {
        message: isChuy
          ? '¡Qué buena onda! En el Chat Comunitario puedes conocer gente muy agradable, compartir experiencias y hacer nuevos cuates. Es un ambiente muy amigable. ¿Te gustaría visitarlo?'
          : '¡Qué lindo! En nuestro Chat Comunitario puedes conocer personas maravillosas, compartir experiencias y hacer nuevos amigos. Es un espacio muy acogedor. ¿Te gustaría visitarlo?',
        suggestedSection: 'chat',
        buttonText: 'Ir al Chat Comunitario'
      };
    }
    
    // Saludos
    if (msg.includes('hola') || msg.includes('buenos') || msg.includes('saludos')) {
      return {
        message: isChuy
          ? '¡Hola amigo! Qué gusto saludarte. Soy Chuy y estoy aquí para ayudarte a disfrutar de todo lo que Recrea Andar tiene para ti. ¿En qué te puedo echar la mano?'
          : '¡Hola querido! Es un placer saludarte. Soy Carmen y estoy aquí para ayudarte a disfrutar de todo lo que Recrea Andar tiene para ti. ¿En qué puedo ayudarte hoy?'
      };
    }
    
    // Agradecimientos
    if (msg.includes('gracias')) {
      return {
        message: isChuy
          ? '¡Para eso estamos, amigo! Es un placer ayudarte. Recuerda que aquí me tienes cuando me necesites. ¿Algo más que quieras saber?'
          : '¡De nada, cariño! Es un placer ayudarte. Recuerda que estoy aquí siempre que me necesites. ¿Hay algo más que quieras saber?'
      };
    }

    // Ayuda o guía general
    if (msg.includes('ayud') || msg.includes('guía') || msg.includes('guia')) {
      return {
        message: isChuy
          ? 'Claro que sí, para eso estoy. Te puedo ayudar con:\\n\\n• Ver las clases disponibles\\n• Agendar citas con profesionales\\n• Encontrar juegos para la mente\\n• Conectarte con la comunidad\\n\\n¿Por dónde arrancamos?'
          : 'Claro que sí, estoy aquí para guiarte. Puedo ayudarte a:\\n\\n• Conocer las clases disponibles\\n• Agendar citas con profesionales\\n• Encontrar juegos para tu mente\\n• Conectarte con la comunidad\\n\\n¿Por dónde empezamos?'
      };
    }
    
    // Respuesta por defecto
    return {
      message: isChuy
        ? 'Entiendo, amigo. Para ayudarte mejor, te puedo mostrar las diferentes secciones. Tenemos actividades recreativas, profesionales de salud, juegos para la mente y una comunidad muy padre. ¿Qué te interesa más?'
        : 'Entiendo, querido. Para ayudarte mejor, puedo mostrarte nuestras diferentes secciones. Tenemos actividades recreativas, profesionales de salud, juegos para la mente y una comunidad muy linda. ¿Qué te interesa más?'
    };
  };

  const handleSend = () => {
    if (newMessage.trim()) {
      const now = new Date();
      const userMsg: ChatMessage = {
        id: messages.length + 1,
        sender: 'user',
        message: newMessage,
        time: now.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages([...messages, userMsg]);
      const currentMsgText = newMessage;
      setNewMessage('');
      setIsTyping(true);
      
      // Detectar y actualizar el estado de ánimo
      const mood = detectMood(currentMsgText);
      setUserMood(mood);
      setMessageCount(messageCount + 1);

      // Simulate Carmen thinking and responding
      setTimeout(() => {
        const response = getBotResponse(currentMsgText);
        const botMsg: ChatMessage = {
          id: messages.length + 2,
          sender: 'bot',
          message: response.message,
          time: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
          suggestedSection: response.suggestedSection,
          buttonText: response.buttonText,
        };
        setMessages((prev) => [...prev, botMsg]);
        setIsTyping(false);
        
        // Después de ciertos mensajes, Carmen pregunta proactivamente
        if ((messageCount + 1) % 5 === 0 && mood === 'neutral') {
          setTimeout(() => {
            const checkInMsg: ChatMessage = {
              id: messages.length + 3,
              sender: 'bot',
              message: 'Por cierto querido, ya hemos hablado un rato y quiero saber... ¿Cómo te estás sintiendo? ¿Hay algo que te preocupe o en lo que pueda ayudarte de alguna manera especial?',
              time: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
            };
            setMessages((prev) => [...prev, checkInMsg]);
          }, 2000);
        }
      }, 1200 + Math.random() * 800);
    }
  };

  const handleQuickQuestion = (question: string) => {
    setNewMessage(question);
  };

  const handleNavigate = (section: 'chat' | 'clases' | 'asesoria' | 'juegos') => {
    if (onNavigate) {
      onNavigate(section);
    }
  };

  const handleSelectGuide = (guide: Guide) => {
    setSelectedGuide(guide);
    const initialMessage: ChatMessage = {
      id: 1,
      sender: 'bot',
      message: guide === 'carmen'
        ? '¡Hola querido! Soy Carmen, tu guía personal en Recrea Andar 😊 Estoy aquí para ayudarte a conocer todas las maravillosas actividades y servicios que tenemos. Pero antes de empezar, cuéntame... ¿cómo te sientes hoy?'
        : '¡Qué onda, amigo! Soy Chuy, tu guía personal en Recrea Andar 👋 Estoy aquí para echarte la mano y mostrarte todas las actividades y servicios que tenemos. Pero primero dime... ¿cómo te la estás llevando hoy?',
      time: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages([initialMessage]);
  };

  // Pantalla de selección de guía
  if (!selectedGuide) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-blue-900 mb-2">Elige tu Guía Personal</h1>
          <p className="text-gray-600">Selecciona el asistente con el que te gustaría interactuar</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Carmen Card */}
          <Card className="hover:shadow-xl transition-shadow cursor-pointer border-2 hover:border-pink-400" onClick={() => handleSelectGuide('carmen')}>
            <CardHeader>
              <div className="flex flex-col items-center">
                <Avatar className="w-32 h-32 border-4 border-pink-300 bg-pink-50 mb-4">
                  <CarmenAvatar />
                </Avatar>
                <h2 className="text-gray-900 text-center">Carmen</h2>
                <Badge className="bg-gradient-to-r from-pink-500 to-purple-500 text-white border-0 flex items-center gap-1 mt-2">
                  <Sparkles className="w-3 h-3" />
                  Guía Empática
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-600">
                Una amiga cálida y comprensiva que te guiará con paciencia y cariño por todas las secciones de la aplicación.
              </p>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-center gap-2">
                  <span className="text-pink-500">•</span>
                  <span>Personalidad amable y maternal</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-pink-500">•</span>
                  <span>Lenguaje cariñoso y empático</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-pink-500">•</span>
                  <span>Detecta y cuida tu estado de ánimo</span>
                </div>
              </div>
              <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 mt-4">
                Elegir a Carmen
              </Button>
            </CardContent>
          </Card>

          {/* Chuy Card */}
          <Card className="hover:shadow-xl transition-shadow cursor-pointer border-2 hover:border-blue-400" onClick={() => handleSelectGuide('chuy')}>
            <CardHeader>
              <div className="flex flex-col items-center">
                <Avatar className="w-32 h-32 border-4 border-blue-300 bg-blue-50 mb-4">
                  <ChuyAvatar />
                </Avatar>
                <h2 className="text-gray-900 text-center">Chuy</h2>
                <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0 flex items-center gap-1 mt-2">
                  <Sparkles className="w-3 h-3" />
                  Guía Amigable
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-600">
                Un amigo cercano y confiable que te apoyará con buen humor y lenguaje amistoso en tu experiencia.
              </p>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-center gap-2">
                  <span className="text-blue-500">•</span>
                  <span>Personalidad amigable y cercana</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-blue-500">•</span>
                  <span>Lenguaje informal y fraternal</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-blue-500">•</span>
                  <span>Detecta y cuida tu estado de ánimo</span>
                </div>
              </div>
              <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 mt-4">
                Elegir a Chuy
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const guideName = selectedGuide === 'carmen' ? 'Carmen' : 'Chuy';
  const guideColors = selectedGuide === 'carmen' 
    ? { border: 'border-pink-300', bg: 'bg-pink-50', text: 'text-pink-600', gradient: 'from-pink-500 to-purple-500', gradientHover: 'from-pink-600 to-purple-600', light: 'from-pink-50 to-purple-50', borderColor: 'border-pink-100', ring: 'ring-pink-400', quickBg: 'from-pink-100 to-purple-100', quickText: 'text-pink-700', quickHover: 'from-pink-200 to-purple-200', quickBorder: 'border-pink-200', badge: 'from-pink-500 to-purple-500', bounce: 'bg-pink-400' }
    : { border: 'border-blue-300', bg: 'bg-blue-50', text: 'text-blue-600', gradient: 'from-blue-500 to-cyan-500', gradientHover: 'from-blue-600 to-cyan-600', light: 'from-blue-50 to-cyan-50', borderColor: 'border-blue-100', ring: 'ring-blue-400', quickBg: 'from-blue-100 to-cyan-100', quickText: 'text-blue-700', quickHover: 'from-blue-200 to-cyan-200', quickBorder: 'border-blue-200', badge: 'from-blue-500 to-cyan-500', bounce: 'bg-blue-400' };
  const GuideAvatar = selectedGuide === 'carmen' ? CarmenAvatar : ChuyAvatar;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <Avatar className={`w-12 h-12 border-2 ${guideColors.border} ${guideColors.bg}`}>
              <GuideAvatar />
            </Avatar>
            <div>
              <h1 className="text-blue-900">{guideName} - Tu Guía Personal</h1>
              <Badge className={`bg-gradient-to-r ${guideColors.badge} text-white border-0 flex items-center gap-1 mt-1`}>
                <Sparkles className="w-3 h-3" />
                Asistente con IA
              </Badge>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => setSelectedGuide(null)}>
            Cambiar Guía
          </Button>
        </div>
        <p className="text-gray-600">
          {selectedGuide === 'carmen' ? 'Una amiga que te guiará por toda la aplicación' : 'Un amigo que te guiará por toda la aplicación'}
        </p>
      </div>

      <Card className="h-[600px] flex flex-col shadow-lg">
        {/* Messages area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id}>
              <div
                className={`flex gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <Avatar className={`w-10 h-10 flex-shrink-0 ${msg.sender === 'bot' ? `border-2 ${guideColors.border} ${guideColors.bg}` : ''}`}>
                  {msg.sender === 'bot' ? (
                    <GuideAvatar />
                  ) : (
                    <AvatarFallback className="bg-blue-600">
                      <User className="w-5 h-5 text-white" />
                    </AvatarFallback>
                  )}
                </Avatar>
                <div className={`flex-1 ${msg.sender === 'user' ? 'text-right' : ''}`}>
                  {msg.sender === 'bot' && (
                    <p className={`${guideColors.text} mb-1`}>{guideName}</p>
                  )}
                  <div
                    className={`inline-block max-w-[80%] ${
                      msg.sender === 'user'
                        ? 'bg-blue-500 text-white'
                        : `bg-gradient-to-br ${guideColors.light} text-gray-900 border ${guideColors.borderColor}`
                    } rounded-2xl px-4 py-3 whitespace-pre-line`}
                  >
                    <p>{msg.message}</p>
                  </div>
                  <p className="text-gray-400 mt-1">{msg.time}</p>
                  
                  {/* Navigation button if suggested */}
                  {msg.suggestedSection && msg.buttonText && (
                    <div className={`mt-2 ${msg.sender === 'user' ? 'flex justify-end' : ''}`}>
                      <button
                        onClick={() => handleNavigate(msg.suggestedSection!)}
                        className={`inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r ${guideColors.gradient} text-white rounded-full hover:${guideColors.gradientHover} transition-all shadow-md hover:shadow-lg`}
                      >
                        {msg.buttonText}
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3">
              <Avatar className={`w-10 h-10 flex-shrink-0 border-2 ${guideColors.border} ${guideColors.bg}`}>
                <GuideAvatar />
              </Avatar>
              <div>
                <p className={`${guideColors.text} mb-1`}>{guideName}</p>
                <div className={`bg-gradient-to-br ${guideColors.light} border ${guideColors.borderColor} rounded-2xl px-4 py-3`}>
                  <div className="flex gap-1">
                    <div className={`w-2 h-2 ${guideColors.bounce} rounded-full animate-bounce`} style={{ animationDelay: '0ms' }} />
                    <div className={`w-2 h-2 ${guideColors.bounce} rounded-full animate-bounce`} style={{ animationDelay: '150ms' }} />
                    <div className={`w-2 h-2 ${guideColors.bounce} rounded-full animate-bounce`} style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Quick questions */}
        {messages.length === 1 && (
          <div className="px-6 pb-4">
            <p className="text-gray-600 mb-2">Pregúntale a {guideName}:</p>
            <div className="flex flex-wrap gap-2">
              {quickQuestions.map((question, index) => (
                <button
                  key={index}
                  onClick={() => handleQuickQuestion(question)}
                  className={`px-3 py-1.5 bg-gradient-to-r ${guideColors.quickBg} ${guideColors.quickText} rounded-full hover:${guideColors.quickHover} transition-colors border ${guideColors.quickBorder}`}
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input area */}
        <div className="border-t border-gray-200 p-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder={`Escribe tu pregunta a ${guideName}...`}
              className={`flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:${guideColors.ring}`}
            />
            <Button onClick={handleSend} className={`bg-gradient-to-r ${guideColors.gradient} hover:${guideColors.gradientHover}`}>
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}