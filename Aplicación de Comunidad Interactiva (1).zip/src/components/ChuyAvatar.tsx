export function ChuyAvatar({ className = "w-full h-full" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 200"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Background circle */}
      <circle cx="100" cy="100" r="95" fill="#dbeafe" />
      
      {/* Body/Neck */}
      <ellipse cx="100" cy="160" rx="45" ry="35" fill="#3b82f6" />
      <rect x="85" y="140" width="30" height="30" fill="#60a5fa" rx="5" />
      
      {/* Head */}
      <circle cx="100" cy="90" r="45" fill="#fcd34d" />
      
      {/* Hair */}
      <path
        d="M 55 75 Q 50 55, 62 48 Q 75 42, 88 45 Q 95 38, 100 36 Q 105 38, 112 45 Q 125 42, 138 48 Q 150 55, 145 75 L 140 85 Q 135 78, 130 75 Q 120 70, 110 72 Q 105 68, 100 68 Q 95 68, 90 72 Q 80 70, 70 75 Q 65 78, 60 85 L 55 75 Z"
        fill="#1f2937"
      />
      
      {/* Hair side details */}
      <path d="M 55 75 L 58 95" stroke="#1f2937" strokeWidth="3" fill="none" />
      <path d="M 145 75 L 142 95" stroke="#1f2937" strokeWidth="3" fill="none" />
      
      {/* Ears */}
      <ellipse cx="58" cy="90" rx="8" ry="12" fill="#fbbf24" />
      <ellipse cx="142" cy="90" rx="8" ry="12" fill="#fbbf24" />
      
      {/* Eyes */}
      <ellipse cx="85" cy="88" rx="9" ry="11" fill="white" />
      <ellipse cx="115" cy="88" rx="9" ry="11" fill="white" />
      <circle cx="86" cy="90" r="6" fill="#4b5563" />
      <circle cx="116" cy="90" r="6" fill="#4b5563" />
      <circle cx="88" cy="88" r="2.5" fill="white" />
      <circle cx="118" cy="88" r="2.5" fill="white" />
      
      {/* Eyebrows */}
      <path d="M 73 78 Q 85 74, 95 76" stroke="#1f2937" strokeWidth="3" fill="none" strokeLinecap="round" />
      <path d="M 105 76 Q 115 74, 127 78" stroke="#1f2937" strokeWidth="3" fill="none" strokeLinecap="round" />
      
      {/* Nose */}
      <path d="M 100 92 L 98 102 L 102 102 Z" fill="#f59e0b" />
      <circle cx="98" cy="102" r="2" fill="#4b5563" opacity="0.3" />
      <circle cx="102" cy="102" r="2" fill="#4b5563" opacity="0.3" />
      
      {/* Mustache */}
      <path
        d="M 75 105 Q 85 108, 100 106 Q 115 108, 125 105 Q 122 110, 115 110 Q 108 109, 100 109 Q 92 109, 85 110 Q 78 110, 75 105 Z"
        fill="#1f2937"
      />
      
      {/* Smile */}
      <path
        d="M 80 112 Q 100 122, 120 112"
        stroke="#dc2626"
        strokeWidth="2.5"
        fill="none"
        strokeLinecap="round"
      />
      
      {/* Friendly wrinkles (smile lines) */}
      <path d="M 125 100 Q 128 105, 128 110" stroke="#f59e0b" strokeWidth="1.5" fill="none" opacity="0.4" />
      <path d="M 75 100 Q 72 105, 72 110" stroke="#f59e0b" strokeWidth="1.5" fill="none" opacity="0.4" />
      
      {/* Collar with tie */}
      <circle cx="100" cy="145" r="3" fill="white" />
      <circle cx="100" cy="155" r="3" fill="white" />
      
      {/* Tie */}
      <polygon points="100,140 95,145 95,165 100,170 105,165 105,145" fill="#1e40af" />
      <polygon points="100,140 92,135 100,145 108,135" fill="#1e40af" />
    </svg>
  );
}
