import { useState } from 'react';
import { Calendar as CalendarIcon, Clock, MapPin, Users, Check, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface Clase {
  id: number;
  title: string;
  description: string;
  instructor: string;
  schedule: string;
  duration: string;
  location: string;
  capacity: string;
  level: string;
  color: string;
  days: number[]; // 0 = Domingo, 1 = Lunes, etc.
  time: string;
}

interface EnrolledClass {
  classId: number;
  className: string;
  days: number[];
  time: string;
  color: string;
}

export function ClasesRecreativas() {
  const [enrolledClasses, setEnrolledClasses] = useState<EnrolledClass[]>([]);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [view, setView] = useState<'classes' | 'calendar'>('classes');

  const clases: Clase[] = [
    {
      id: 1,
      title: 'Yoga para Adultos Mayores',
      description: 'Sesiones de yoga adaptadas para mejorar flexibilidad y equilibrio',
      instructor: 'Laura Mendoza',
      schedule: 'Lunes y Miércoles, 4:00 PM',
      duration: '1 hora',
      location: 'Sala Principal',
      capacity: '15/20 inscritos',
      level: 'Todos los niveles',
      color: 'bg-purple-500',
      days: [1, 3], // Lunes y Miércoles
      time: '4:00 PM',
    },
    {
      id: 2,
      title: 'Baile y Movimiento',
      description: 'Aprende ritmos latinos mientras te ejercitas de forma divertida',
      instructor: 'Roberto Sánchez',
      schedule: 'Martes y Jueves, 10:00 AM',
      duration: '1.5 horas',
      location: 'Salón de Baile',
      capacity: '12/15 inscritos',
      level: 'Principiante',
      color: 'bg-pink-500',
      days: [2, 4], // Martes y Jueves
      time: '10:00 AM',
    },
    {
      id: 3,
      title: 'Pintura y Arte',
      description: 'Desarrolla tu creatividad con técnicas de pintura en acuarela',
      instructor: 'Carmen Flores',
      schedule: 'Viernes, 3:00 PM',
      duration: '2 horas',
      location: 'Taller de Arte',
      capacity: '8/12 inscritos',
      level: 'Todos los niveles',
      color: 'bg-orange-500',
      days: [5], // Viernes
      time: '3:00 PM',
    },
    {
      id: 4,
      title: 'Tai Chi',
      description: 'Ejercicios suaves para mejorar el balance y reducir el estrés',
      instructor: 'Miguel Chen',
      schedule: 'Lunes, Miércoles y Viernes, 8:00 AM',
      duration: '45 minutos',
      location: 'Jardín Exterior',
      capacity: '18/25 inscritos',
      level: 'Todos los niveles',
      color: 'bg-green-500',
      days: [1, 3, 5], // Lunes, Miércoles y Viernes
      time: '8:00 AM',
    },
    {
      id: 5,
      title: 'Club de Lectura',
      description: 'Comparte y discute tus libros favoritos con otros lectores',
      instructor: 'Elena Vargas',
      schedule: 'Sábados, 11:00 AM',
      duration: '1.5 horas',
      location: 'Biblioteca',
      capacity: '10/15 inscritos',
      level: 'Todos los niveles',
      color: 'bg-blue-500',
      days: [6], // Sábado
      time: '11:00 AM',
    },
    {
      id: 6,
      title: 'Cocina Saludable',
      description: 'Aprende recetas nutritivas y deliciosas',
      instructor: 'Chef Antonio Ruiz',
      schedule: 'Jueves, 2:00 PM',
      duration: '2 horas',
      location: 'Cocina Comunitaria',
      capacity: '6/10 inscritos',
      level: 'Principiante',
      color: 'bg-red-500',
      days: [4], // Jueves
      time: '2:00 PM',
    },
    {
      id: 7,
      title: 'Prevención de Caídas',
      description: 'Aprende técnicas seguras para caer sin lastimarte, ejercicios de equilibrio y fortalecimiento para prevenir caídas',
      instructor: 'Lic. Fernando Castro',
      schedule: 'Martes y Viernes, 9:00 AM',
      duration: '1 hora',
      location: 'Sala de Fisioterapia',
      capacity: '10/15 inscritos',
      level: 'Todos los niveles',
      color: 'bg-teal-500',
      days: [2, 5], // Martes y Viernes
      time: '9:00 AM',
    },
  ];

  const handleEnroll = (clase: Clase) => {
    const isEnrolled = enrolledClasses.some(c => c.classId === clase.id);
    
    if (isEnrolled) {
      setEnrolledClasses(enrolledClasses.filter(c => c.classId !== clase.id));
    } else {
      setEnrolledClasses([...enrolledClasses, {
        classId: clase.id,
        className: clase.title,
        days: clase.days,
        time: clase.time,
        color: clase.color,
      }]);
    }
  };

  const isEnrolled = (claseId: number) => {
    return enrolledClasses.some(c => c.classId === claseId);
  };

  // Funciones del calendario
  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay();
  };

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

  const getClassesForDay = (day: number, month: number, year: number) => {
    const date = new Date(year, month, day);
    const dayOfWeek = date.getDay();
    
    return enrolledClasses.filter(enrolledClass => 
      enrolledClass.days.includes(dayOfWeek)
    );
  };

  const previousMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentMonth, currentYear);
    const firstDay = getFirstDayOfMonth(currentMonth, currentYear);
    const days = [];

    // Días vacíos antes del primer día del mes
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="p-2 min-h-24"></div>);
    }

    // Días del mes
    for (let day = 1; day <= daysInMonth; day++) {
      const classesForDay = getClassesForDay(day, currentMonth, currentYear);
      const isToday = 
        day === new Date().getDate() &&
        currentMonth === new Date().getMonth() &&
        currentYear === new Date().getFullYear();

      days.push(
        <div
          key={day}
          className={`p-2 border border-gray-200 min-h-24 rounded-lg ${
            isToday ? 'bg-blue-50 border-blue-300' : 'bg-white'
          }`}
        >
          <div className={`mb-1 ${isToday ? 'text-blue-600' : 'text-gray-700'}`}>
            {day}
          </div>
          <div className="space-y-1">
            {classesForDay.map((enrolledClass, idx) => (
              <div
                key={idx}
                className={`text-xs ${enrolledClass.color} text-white px-2 py-1 rounded truncate`}
                title={`${enrolledClass.className} - ${enrolledClass.time}`}
              >
                {enrolledClass.className}
              </div>
            ))}
          </div>
        </div>
      );
    }

    return days;
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-blue-900 mb-2">Clases Recreativas</h1>
          <p className="text-gray-600">Descubre nuestras actividades diseñadas para tu bienestar</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setView('classes')}
            variant={view === 'classes' ? 'default' : 'outline'}
            className={view === 'classes' ? 'bg-blue-500 hover:bg-blue-600' : ''}
          >
            Clases Disponibles
          </Button>
          <Button
            onClick={() => setView('calendar')}
            variant={view === 'calendar' ? 'default' : 'outline'}
            className={view === 'calendar' ? 'bg-blue-500 hover:bg-blue-600' : ''}
          >
            <CalendarIcon className="w-4 h-4 mr-2" />
            Mi Calendario
          </Button>
        </div>
      </div>

      {view === 'classes' ? (
        <>
          {enrolledClasses.length > 0 && (
            <Card className="mb-6 bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-gray-900 flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-500" />
                  Clases Inscritas ({enrolledClasses.length})
                </CardTitle>
                <CardDescription>
                  Estás inscrito en {enrolledClasses.length} {enrolledClasses.length === 1 ? 'clase' : 'clases'}
                </CardDescription>
              </CardHeader>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {clases.map((clase) => {
              const enrolled = isEnrolled(clase.id);
              return (
                <Card key={clase.id} className={`hover:shadow-lg transition-shadow ${enrolled ? 'border-green-400 border-2' : ''}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <CardTitle className="text-gray-900 flex items-center gap-2">
                        {clase.title}
                        {enrolled && <Check className="w-5 h-5 text-green-500" />}
                      </CardTitle>
                      <Badge className={`${clase.color} text-white border-0`}>
                        {clase.level}
                      </Badge>
                    </div>
                    <CardDescription>{clase.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2 text-gray-700">
                      <Users className="w-4 h-4 text-blue-500" />
                      <span>{clase.instructor}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <CalendarIcon className="w-4 h-4 text-green-500" />
                      <span>{clase.schedule}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <Clock className="w-4 h-4 text-purple-500" />
                      <span>{clase.duration}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <MapPin className="w-4 h-4 text-red-500" />
                      <span>{clase.location}</span>
                    </div>
                    <div className="pt-2">
                      <p className="text-gray-600 mb-3">{clase.capacity}</p>
                      <Button
                        className={`w-full ${
                          enrolled
                            ? 'bg-red-500 hover:bg-red-600'
                            : 'bg-blue-500 hover:bg-blue-600'
                        }`}
                        onClick={() => handleEnroll(clase)}
                      >
                        {enrolled ? (
                          <>
                            <X className="w-4 h-4 mr-2" />
                            Cancelar Inscripción
                          </>
                        ) : (
                          <>
                            <Check className="w-4 h-4 mr-2" />
                            Inscribirse
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </>
      ) : (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-gray-900">Mi Calendario de Clases</CardTitle>
              <div className="flex items-center gap-4">
                <Button variant="outline" size="sm" onClick={previousMonth}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-gray-700 min-w-[150px] text-center">
                  {monthNames[currentMonth]} {currentYear}
                </span>
                <Button variant="outline" size="sm" onClick={nextMonth}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
            {enrolledClasses.length === 0 && (
              <CardDescription className="text-center py-4">
                No estás inscrito en ninguna clase. Ve a "Clases Disponibles" para inscribirte.
              </CardDescription>
            )}
          </CardHeader>
          {enrolledClasses.length > 0 && (
            <CardContent>
              <div className="grid grid-cols-7 gap-2 mb-2">
                {dayNames.map(day => (
                  <div key={day} className="text-center text-gray-600 py-2">
                    {day}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-2">
                {renderCalendar()}
              </div>
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h3 className="text-gray-700 mb-3">Leyenda:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {enrolledClasses.map(enrolledClass => (
                    <div key={enrolledClass.classId} className="flex items-center gap-2">
                      <div className={`w-4 h-4 rounded ${enrolledClass.color}`}></div>
                      <span className="text-gray-700">{enrolledClass.className} - {enrolledClass.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
}