import { useState } from 'react';
import { Brain, Trophy, Star, Play, RotateCcw, Search } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface Game {
  id: number;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  benefits: string;
  icon: string;
  color: string;
}

export function JuegosCognitivos() {
  const [memoryCards, setMemoryCards] = useState<number[]>([]);
  const [shuffledSymbols, setShuffledSymbols] = useState<string[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchedPairs, setMatchedPairs] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  
  // Estados para sopa de letras
  const [activeGame, setActiveGame] = useState<'none' | 'memory' | 'wordsearch'>('none');
  const [wordSearchGrid, setWordSearchGrid] = useState<string[][]>([]);
  const [foundWords, setFoundWords] = useState<string[]>([]);
  const [selectedCells, setSelectedCells] = useState<string[]>([]);
  const [wordSearchScore, setWordSearchScore] = useState(0);

  const games: Game[] = [
    {
      id: 1,
      title: 'Memoria de Pares',
      description: 'Encuentra las parejas de cartas iguales',
      category: 'Memoria',
      difficulty: 'Fácil',
      benefits: 'Mejora la memoria a corto plazo',
      icon: '🎴',
      color: 'bg-blue-500',
    },
    {
      id: 2,
      title: 'Sopa de Letras',
      description: 'Encuentra todas las palabras escondidas',
      category: 'Atención',
      difficulty: 'Medio',
      benefits: 'Mejora concentración y reconocimiento de patrones',
      icon: '🔤',
      color: 'bg-indigo-500',
    },
    {
      id: 3,
      title: 'Sudoku',
      description: 'Completa el tablero con números del 1 al 9',
      category: 'Lógica',
      difficulty: 'Medio',
      benefits: 'Estimula el razonamiento lógico',
      icon: '🔢',
      color: 'bg-green-500',
    },
    {
      id: 4,
      title: 'Crucigramas',
      description: 'Resuelve definiciones y completa palabras',
      category: 'Lenguaje',
      difficulty: 'Medio',
      benefits: 'Amplía vocabulario y memoria semántica',
      icon: '📝',
      color: 'bg-purple-500',
    },
    {
      id: 5,
      title: 'Rompecabezas',
      description: 'Arma la imagen completa con las piezas',
      category: 'Visual',
      difficulty: 'Fácil',
      benefits: 'Mejora percepción visual y espacial',
      icon: '🧩',
      color: 'bg-orange-500',
    },
    {
      id: 6,
      title: 'Encuentra las Diferencias',
      description: 'Identifica las diferencias entre dos imágenes',
      category: 'Atención',
      difficulty: 'Fácil',
      benefits: 'Aumenta concentración y atención',
      icon: '🔍',
      color: 'bg-pink-500',
    },
    {
      id: 7,
      title: 'Secuencias Numéricas',
      description: 'Completa la serie de números',
      category: 'Lógica',
      difficulty: 'Difícil',
      benefits: 'Desarrolla pensamiento abstracto',
      icon: '➕',
      color: 'bg-red-500',
    },
  ];

  const baseSymbols = ['🌟', '🎨', '🌺', '🎵', '🦋', '☀️'];

  const initializeMemoryGame = () => {
    // Crear pares y revolverlos completamente
    const pairs = [...baseSymbols, ...baseSymbols];
    const shuffled = [...pairs].sort(() => Math.random() - 0.5);
    setShuffledSymbols(shuffled);
    setMemoryCards(shuffled.map((_, i) => i));
    setFlippedCards([]);
    setMatchedPairs([]);
    setScore(0);
    setActiveGame('memory');
  };

  const handleCardClick = (index: number) => {
    if (flippedCards.length === 2 || flippedCards.includes(index) || matchedPairs.includes(index)) {
      return;
    }

    const newFlipped = [...flippedCards, index];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      const [first, second] = newFlipped;
      if (shuffledSymbols[first] === shuffledSymbols[second]) {
        setMatchedPairs([...matchedPairs, first, second]);
        setScore(score + 10);
        setFlippedCards([]);
      } else {
        setTimeout(() => setFlippedCards([]), 1000);
      }
    }
  };

  // Funciones para sopa de letras
  const wordsToFind = ['YOGA', 'SALUD', 'MENTE', 'ALEGRIA', 'AMISTAD', 'RECREO'];

  const initializeWordSearch = () => {
    const size = 10;
    const grid: string[][] = Array(size).fill(null).map(() => Array(size).fill(''));
    
    // Colocar palabras en el grid
    wordsToFind.forEach(word => {
      let placed = false;
      let attempts = 0;
      
      while (!placed && attempts < 100) {
        const direction = Math.random() > 0.5 ? 'horizontal' : 'vertical';
        const row = Math.floor(Math.random() * size);
        const col = Math.floor(Math.random() * size);
        
        if (direction === 'horizontal' && col + word.length <= size) {
          let canPlace = true;
          for (let i = 0; i < word.length; i++) {
            if (grid[row][col + i] !== '' && grid[row][col + i] !== word[i]) {
              canPlace = false;
              break;
            }
          }
          if (canPlace) {
            for (let i = 0; i < word.length; i++) {
              grid[row][col + i] = word[i];
            }
            placed = true;
          }
        } else if (direction === 'vertical' && row + word.length <= size) {
          let canPlace = true;
          for (let i = 0; i < word.length; i++) {
            if (grid[row + i][col] !== '' && grid[row + i][col] !== word[i]) {
              canPlace = false;
              break;
            }
          }
          if (canPlace) {
            for (let i = 0; i < word.length; i++) {
              grid[row + i][col] = word[i];
            }
            placed = true;
          }
        }
        attempts++;
      }
    });
    
    // Rellenar espacios vacíos con letras aleatorias
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for (let i = 0; i < size; i++) {
      for (let j = 0; j < size; j++) {
        if (grid[i][j] === '') {
          grid[i][j] = letters[Math.floor(Math.random() * letters.length)];
        }
      }
    }
    
    setWordSearchGrid(grid);
    setFoundWords([]);
    setSelectedCells([]);
    setWordSearchScore(0);
    setActiveGame('wordsearch');
  };

  const handleCellClick = (row: number, col: number) => {
    const cellId = `${row}-${col}`;
    
    if (selectedCells.includes(cellId)) {
      setSelectedCells(selectedCells.filter(c => c !== cellId));
    } else {
      const newSelected = [...selectedCells, cellId];
      setSelectedCells(newSelected);
      
      // Verificar si se formó una palabra
      checkForWord(newSelected);
    }
  };

  const checkForWord = (cells: string[]) => {
    if (cells.length < 3) return;
    
    // Extraer las letras seleccionadas
    const letters = cells.map(cell => {
      const [row, col] = cell.split('-').map(Number);
      return wordSearchGrid[row][col];
    }).join('');
    
    // Verificar si coincide con alguna palabra
    wordsToFind.forEach(word => {
      if ((letters === word || letters === word.split('').reverse().join('')) && !foundWords.includes(word)) {
        setFoundWords([...foundWords, word]);
        setWordSearchScore(wordSearchScore + 20);
        setSelectedCells([]);
      }
    });
  };

  const handleGameClick = (gameId: number) => {
    if (gameId === 1) {
      initializeMemoryGame();
    } else if (gameId === 2) {
      initializeWordSearch();
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-blue-900 mb-2">Juegos Cognitivos</h1>
        <p className="text-gray-600">Ejercita tu mente de forma divertida y efectiva</p>
      </div>

      {/* Featured Game - Memory Game */}
      {activeGame === 'memory' && (
        <Card className="mb-8 bg-gradient-to-br from-blue-50 to-purple-50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-gray-900 flex items-center gap-2">
                  <Brain className="w-6 h-6 text-blue-500" />
                  Juego Destacado: Memoria de Pares
                </CardTitle>
                <CardDescription>Encuentra todas las parejas de símbolos</CardDescription>
              </div>
              <div className="flex items-center gap-4">
                <Badge className="bg-green-500 text-white border-0 flex items-center gap-1">
                  <Trophy className="w-4 h-4" />
                  Puntos: {score}
                </Badge>
                <Button onClick={initializeMemoryGame} variant="outline" size="sm">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reiniciar
                </Button>
                <Button onClick={() => setActiveGame('none')} variant="outline" size="sm">
                  Volver
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 md:grid-cols-6 gap-3">
              {memoryCards.map((_, index) => (
                <button
                  key={index}
                  onClick={() => handleCardClick(index)}
                  className={`aspect-square rounded-lg transition-all transform hover:scale-105 ${
                    flippedCards.includes(index) || matchedPairs.includes(index)
                      ? 'bg-white border-2 border-blue-500'
                      : 'bg-gradient-to-br from-blue-400 to-blue-600'
                  } ${matchedPairs.includes(index) ? 'opacity-50' : ''}`}
                >
                  {flippedCards.includes(index) || matchedPairs.includes(index) ? (
                    <span className="text-4xl">{shuffledSymbols[index]}</span>
                  ) : (
                    <Star className="w-8 h-8 text-white mx-auto" />
                  )}
                </button>
              ))}
            </div>
            {matchedPairs.length === shuffledSymbols.length && memoryCards.length > 0 && (
              <div className="text-center mt-6 p-4 bg-green-100 rounded-lg">
                <p className="text-green-800">
                  ¡Felicitaciones! Has completado el juego con {score} puntos
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Word Search Game */}
      {activeGame === 'wordsearch' && (
        <Card className="mb-8 bg-gradient-to-br from-indigo-50 to-purple-50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-gray-900 flex items-center gap-2">
                  <Search className="w-6 h-6 text-indigo-500" />
                  Juego Destacado: Sopa de Letras
                </CardTitle>
                <CardDescription>Encuentra todas las palabras escondidas</CardDescription>
              </div>
              <div className="flex items-center gap-4">
                <Badge className="bg-green-500 text-white border-0 flex items-center gap-1">
                  <Trophy className="w-4 h-4" />
                  Puntos: {wordSearchScore}
                </Badge>
                <Button onClick={initializeWordSearch} variant="outline" size="sm">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reiniciar
                </Button>
                <Button onClick={() => setActiveGame('none')} variant="outline" size="sm">
                  Volver
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <h3 className="text-gray-700 mb-2">Palabras para encontrar:</h3>
              <div className="flex flex-wrap gap-2">
                {wordsToFind.map(word => (
                  <Badge
                    key={word}
                    className={`${
                      foundWords.includes(word)
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-200 text-gray-700'
                    } border-0`}
                  >
                    {word} {foundWords.includes(word) && '✓'}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="grid gap-1 max-w-lg mx-auto" style={{ gridTemplateColumns: `repeat(10, minmax(0, 1fr))` }}>
              {wordSearchGrid.map((row, rowIndex) =>
                row.map((letter, colIndex) => {
                  const cellId = `${rowIndex}-${colIndex}`;
                  const isSelected = selectedCells.includes(cellId);
                  return (
                    <button
                      key={cellId}
                      onClick={() => handleCellClick(rowIndex, colIndex)}
                      className={`aspect-square flex items-center justify-center border border-gray-300 rounded transition-all ${
                        isSelected
                          ? 'bg-indigo-500 text-white'
                          : 'bg-white hover:bg-indigo-100'
                      }`}
                    >
                      {letter}
                    </button>
                  );
                })
              )}
            </div>
            {foundWords.length === wordsToFind.length && (
              <div className="text-center mt-6 p-4 bg-green-100 rounded-lg">
                <p className="text-green-800">
                  ¡Felicitaciones! Has encontrado todas las palabras con {wordSearchScore} puntos
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Game Selection */}
      {activeGame === 'none' && (
        <>
          <h2 className="text-gray-900 mb-4">Selecciona un Juego</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game) => (
              <Card key={game.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div className="text-5xl mb-3">{game.icon}</div>
                    <Badge className={`${game.color} text-white border-0`}>
                      {game.difficulty}
                    </Badge>
                  </div>
                  <CardTitle className="text-gray-900">{game.title}</CardTitle>
                  <CardDescription>{game.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-blue-600 border-blue-600">
                      {game.category}
                    </Badge>
                  </div>
                  <p className="text-gray-600">
                    <Brain className="w-4 h-4 inline mr-2 text-purple-500" />
                    {game.benefits}
                  </p>
                  <Button 
                    className="w-full bg-blue-500 hover:bg-blue-600 mt-4"
                    onClick={() => handleGameClick(game.id)}
                    disabled={game.id > 2}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {game.id <= 2 ? 'Jugar Ahora' : 'Próximamente'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
