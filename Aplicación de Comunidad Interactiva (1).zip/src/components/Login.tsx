import { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import backgroundImage from 'figma:asset/5c41de829604f1465fd0aefe479721188de4400b.png';
import newBackgroundImage from 'figma:asset/6a39638c1a1559d9efc05d1309748dfff0e7ce65.png';
import logoImage from 'figma:asset/596b9a041c4e6a36f2b868cabd020f0b4f5c20bf.png';

interface LoginProps {
  onLogin: () => void;
}

export function Login({ onLogin }: LoginProps) {
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: `url(${newBackgroundImage})`,
          filter: 'brightness(0.5) saturate(0.7)'
        }}
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/20" />

      {/* Login Card */}
      <div className="relative z-10 w-full max-w-sm">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Logo */}
          <div className="flex justify-center mb-12">
            <h1 className="text-white text-5xl">Recrea Andar</h1>
          </div>

          {/* Username Input */}
          <div>
            <input
              type="text"
              placeholder="Username"
              className="w-full px-6 py-4 rounded-full bg-white/90 backdrop-blur-sm border-2 border-[#A8D5BA] text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#A8D5BA] text-center shadow-lg"
            />
          </div>

          {/* Password Input */}
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              className="w-full px-6 py-4 rounded-full bg-white/90 backdrop-blur-sm border-2 border-[#A8D5BA] text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#A8D5BA] text-center shadow-lg"
            />
            <button
              type="button"
              className="absolute right-4 top-1/2 transform -translate-y-1/2"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>

          {/* Login Button */}
          <div>
            <button
              type="submit"
              className="w-full px-6 py-4 rounded-full bg-[#FF7B3D] text-white hover:bg-[#FF6B2D] transition-colors shadow-lg"
            >
              Log in
            </button>
          </div>

          {/* Forgot Password Link */}
          <div className="text-center">
            <button
              type="button"
              className="text-white text-sm hover:underline"
            >
              Forgot password
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}